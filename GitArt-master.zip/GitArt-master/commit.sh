git add dummy.txt
git commit -m "Update."
git push origin master
